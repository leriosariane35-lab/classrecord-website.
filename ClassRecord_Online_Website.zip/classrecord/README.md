# ClassRecord — Online Absence & Excuse Letter Portal

A responsive class documentation portal built with HTML, CSS, JavaScript modules, Firebase Authentication, Cloud Firestore, Firebase Storage, and jsPDF.

## Included
- Admin and adviser sign-in
- Student directory and individual absence history
- Upload excuse letters as PDF/JPG/PNG (10 MB maximum)
- Pending / verified document status
- Search and status filters
- Year-end PDF summary export
- Firestore and Storage security rules

## Important limitations in this starter
- This is a working starter application, but it is **not live until you configure Firebase and deploy it**.
- Student and absence record creation is currently restricted to the admin role.
- Adviser accounts are view-only in this version. The adviser can inspect records and download the annual summary, but cannot change student records.
- The annual PDF is a summary and does not merge the original uploaded scans into one PDF. The original letters remain in secure Firebase Storage.
- This app is not a substitute for your school's official attendance system or records-retention policy.

## 1. Create your Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web App to the project.
3. Copy the Firebase web configuration into `public/firebase-config.js`.
4. In Firebase Console, enable **Authentication → Sign-in method → Email/Password**.
5. Create a **Cloud Firestore** database.
6. Enable **Storage**.
7. In Authentication → Settings → Authorized domains, ensure your deployed domain is listed.

## 2. Create the first administrator and adviser
1. In Firebase Authentication → Users, add the admin account using an email and a strong temporary password.
2. Copy that account's UID.
3. In Firestore, create a collection named `users`.
4. Add a document whose document ID is exactly the admin UID. Add field `role` (string) = `admin`.
5. Repeat for the adviser's account, but set `role` = `adviser`.
6. Share credentials privately and have each person change their password after first sign-in if your setup supports that workflow.

**Do not let users choose their own role.** The app intentionally does not include public sign-up. User role documents must be created by the trusted administrator in the Firebase Console.

## 3. Deploy security rules
From the project folder, install the Firebase CLI and sign in:

```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only firestore:rules,storage
```

The `firestore.rules` and `storage.rules` files in this project restrict access to signed-in users with an authorized `admin` or `adviser` role. Admins can manage student and absence records; advisers can read records and documents.

## 4. Deploy the website
Install Node.js, then from the project folder run:

```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only hosting
```

The website URL will appear after deployment.

## 5. Run locally for testing
Firebase browser modules require a local web server; do not open `index.html` directly as a file.

```bash
python -m http.server 8000 -d public
```

Then visit http://localhost:8000. Use a Firebase account created in your project.

## 6. Daily workflow
1. Admin signs in and adds the class roster under Student Directory.
2. Admin adds an absence record for the relevant student and date.
3. Attach the excuse letter scan/photo or PDF.
4. Adviser signs in to review student profiles and records.
5. Adviser can export the class summary from Reports & Exports at the end of the year.

## Privacy and school approval checklist
- Get adviser/school approval before collecting student documents.
- Collect only information needed to document an absence.
- Do not use public file links or make the Storage bucket public.
- Restrict access to the class admin and adviser only.
- Use strong passwords and enable multi-factor authentication where available.
- Do not upload sensitive medical records unless specifically required and approved by the school.
- Confirm with the school how long these records should be retained and when they should be deleted.
- Avoid sharing screenshots or exported PDFs in public group chats.

## Customization
Update the class name, section, school year, and adviser details in the Reports & Exports page. Add students through the dashboard after signing in as an admin.
